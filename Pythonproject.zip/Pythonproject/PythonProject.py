# Import libraries
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick

# Set theme
sns.set(style="whitegrid")
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['axes.titlesize'] = 14

# Load dataset
df = sns.load_dataset("titanic")
# if you want to read the file locally, then download the "titanic.csv" and uncomment the line below
#df = pd.read_csv('titanic.csv')

# 1. Data Cleaning
df.drop(['deck', 'embark_town'], axis=1, inplace=True)
df['age'] = df['age'].fillna(df['age'].median())
df['embarked'] = df['embarked'].fillna(df['embarked'].mode()[0])

df['sex'] = df['sex'].astype('category')
df['embarked'] = df['embarked'].astype('category')
df['class'] = df['class'].astype('category')

# 2. Summary Statistics
print("Summary Statistics:")
print(df.describe(include='all'))

# 3. Missing Data Visualization
plt.figure(figsize=(10, 4))
sns.heatmap(df.isnull(), cbar=False, cmap="YlGnBu")
plt.title("Missing Data Heatmap")
plt.show(block=False)

# 4. Survival Rate Analysis
# By Gender
plt.figure(figsize=(6, 4))
sns.barplot(x='sex', y='survived', data=df, palette='pastel')
plt.title('Survival Rate by Gender')
plt.ylabel('Survival Rate')
plt.ylim(0, 1)
plt.gca().yaxis.set_major_formatter(mtick.PercentFormatter(1.0))
plt.show(block=False)

# By Class
plt.figure(figsize=(6, 4))
sns.barplot(x='pclass', y='survived', data=df, palette='Set3')
plt.title('Survival Rate by Passenger Class')
plt.ylim(0, 1)
plt.gca().yaxis.set_major_formatter(mtick.PercentFormatter(1.0))
plt.show(block=False)

# By Embarkation Port
plt.figure(figsize=(6, 4))
sns.barplot(x='embarked', y='survived', data=df, palette='husl')
plt.title('Survival Rate by Embarkation Port')
plt.ylim(0, 1)
plt.gca().yaxis.set_major_formatter(mtick.PercentFormatter(1.0))
plt.show(block=False)

# 5. Distribution Analysis
# Age Distribution
plt.figure(figsize=(8, 4))
sns.histplot(df['age'], kde=True, bins=30, color='coral', alpha=0.8)
plt.title('Age Distribution')
plt.show(block=False)

# Fare Distribution
plt.figure(figsize=(8, 4))
sns.histplot(df['fare'], kde=True, bins=30, color='teal', alpha=0.8)
plt.title('Fare Distribution')
plt.show(block=False)

# 6. Correlation Matrix
plt.figure(figsize=(10, 8))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap='coolwarm', linewidths=0.5)
plt.title('Feature Correlation Heatmap')
plt.show(block=False)

# 7. Pair Plot
sns.pairplot(df[['survived', 'age', 'fare', 'pclass']], hue='survived', palette='Set2')
plt.suptitle("Pairwise Feature Comparison", y=1.02)
plt.show(block=False)

# 8. Additional Charts
# Survival by Age Group
df['age_group'] = pd.cut(df['age'], bins=[0, 12, 18, 35, 60, 100],
                         labels=['Child', 'Teen', 'Young Adult', 'Adult', 'Senior'])

plt.figure(figsize=(8, 4))
sns.barplot(x='age_group', y='survived', data=df, palette='Spectral')
plt.title('Survival Rate by Age Group')
plt.ylim(0, 1)
plt.gca().yaxis.set_major_formatter(mtick.PercentFormatter(1.0))
plt.show(block=False)

# Count of passengers by class and gender
plt.figure(figsize=(8, 4))
sns.countplot(x='class', hue='sex', data=df, palette='Accent')
plt.title('Passenger Count by Class and Gender')
plt.show(block=False)

# Violin Plot: Age vs Survival by Gender
plt.figure(figsize=(8, 5))
sns.violinplot(x='sex', y='age', hue='survived', data=df, split=True, palette='muted')
plt.title('Age Distribution by Gender and Survival')
plt.show(block=False)

# 9. Pie Chart: Gender Distribution
gender_counts = df['sex'].value_counts()
plt.figure(figsize=(5, 5))
plt.pie(gender_counts, labels=gender_counts.index, autopct='%1.1f%%', colors=['#ff9999', '#66b3ff'])
plt.title('Gender Distribution')
plt.show(block=False)

# 10. Data Preparation for Modeling
df_model = pd.get_dummies(df.drop(['age_group'], axis=1), columns=['sex', 'embarked', 'class'], drop_first=True)

print("\nData ready for modeling. Columns:")
print(df_model.columns)

# Pause at the end to keep all plot windows open
plt.pause(0.001)
input("Press Enter to close all plots and exit...")

.4